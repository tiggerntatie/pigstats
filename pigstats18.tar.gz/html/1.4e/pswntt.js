// PigStats for JavaScript 
// Weapon Name Translation Table  (WNTT)

// Counter-Strike weapons:
wntt["mp5navy"]="H&K MP5-Navy"
wntt["m4a1"]="Colt M4A1 Carbine"
wntt["p90"]="FN P90"
wntt["tmp"]="Steyr Tactical"
wntt["sg552"]="Sig SG-552 Commando"
wntt["ak47"]="AK-47"
wntt["g3sg1"]="H&K G3/SG-1"
wntt["awp"]="AI Arctic Warfare/Magnum"
wntt["deagle"]="Desert Eagle"
wntt["glock18"]="Glock 18 Select Fire"
wntt["usp"]="H&K USP .45 Tactical"
wntt["m249"]="FN M249 Para"
wntt["xm1014"]="Benneli XM1014"
wntt["p228"]="SIG P228"
wntt["m3"]="Benneli M3 Super90"
wntt["scout"]="Steyr Scout"
wntt["mac10"]="Ingram MAC-10"
wntt["aug"]="Steyr Aug"
